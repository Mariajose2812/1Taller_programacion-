/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.ejercicio2_con_foreach;

/**
 *
 * @author Maria jose
 */
//EJERCICIO 2 CON FOREACH

import java.util.Arrays;
import java.util.Scanner;

public class Ejercicio2_con_foreach {

    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {
       int NumeroA= (int)(Math.random()*10+1);
     
     Scanner teclado = new Scanner(System.in);
     System.out.println("NUMERO:"+ NumeroA);
     int lectorDeNumeros;
        
        
        
    int[] numbers = new int[NumeroA];
    int sum = 0;
    int mode = 0;
    int maxCount = 0;
    
    
    
     for (int i = 0; i < numbers.length; i++) {
      System.out.println("Estas ingresando el numero #: " + (i+1));
      lectorDeNumeros=teclado.nextInt();
      numbers[i] = i;
      sum += i;
      numbers[i] = lectorDeNumeros;
    }
    
    int average = sum / numbers.length;
    System.out.println("Media: " + average);
    
    Arrays.sort(numbers);
    
    int currentCount = 1;
    int currentNumber = numbers[0];
    for (int number : numbers) {
      if (number == currentNumber) {
        currentCount++;
      } else {
        if (currentCount > maxCount) {
          mode = currentNumber;
          maxCount = currentCount;
        }
        currentNumber = number;
        currentCount = 1;
      }
    }
    
    System.out.println("Moda: " + mode);
  }
}
    
    
    

