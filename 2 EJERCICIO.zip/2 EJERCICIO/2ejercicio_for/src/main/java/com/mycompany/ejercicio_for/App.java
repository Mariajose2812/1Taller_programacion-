/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.ejercicio_for;

/**
 *
 * @author Maria jose
 */
//EJERCICIO 2 CON FOR 

import java.util.Arrays;
import java.util.Scanner;
public class App {

    public static void main(String[] args) {
        int NumeroA= (int)(Math.random()*10+1);
        
         Scanner teclado = new Scanner(System.in);
         System.out.println("NUMERO:"+ NumeroA);
      int lectorDeNumeros;
                  
    int[] numbers = new int[NumeroA];
    int sum = 0;
    int mode = 0;
    int maxCount = 0;
    
    for (int m = 0; m < numbers.length; m++) {
       System.out.println("Estas ingresando el numero #: " + (m+1));
       lectorDeNumeros=teclado.nextInt();
      numbers[m] = lectorDeNumeros;
       
    }
    
    int average = sum / numbers.length;
    System.out.println("Media: " + average);
    
    Arrays.sort(numbers);
    
    int currentCount = 1;
    int currentNumber = numbers[0];
    for (int p = 1; p < numbers.length; p++) {
      if (numbers[p] == currentNumber) {
        currentCount++;
      } else {
        if (currentCount > maxCount) {
          mode = currentNumber;
          maxCount = currentCount;
        }
        currentNumber = numbers[p];
        currentCount = 1;
      }
    }
    
    System.out.println("Moda: " + mode);
    
    }
}
    
    
            