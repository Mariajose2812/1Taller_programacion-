/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.ejercicio2_con_dowhile;

/**
 *
 * @author Maria jose
 */
//EJERCICIO 2 CON DO WHILE

import java.util.Arrays;
import java.util.Scanner;
public class Ejercicio2_con_dowhile {

    public static void main(String[] args) {
     int NumeroA= (int)(Math.random()*10+1);
     
     Scanner teclado = new Scanner(System.in);
         System.out.println("NUMERO:"+ NumeroA);
      int lectorDeNumeros;
        
        
        
    int[] numbers = new int[NumeroA];
    int sum = 0;
    int mode = 0;
    int maxCount = 0;
    int i = 0;
    
    do {
          i++;
        System.out.println("Estas ingresando el numero #:" + (i));
       lectorDeNumeros=teclado.nextInt();
                numbers[i-1] = lectorDeNumeros;
      sum = sum+lectorDeNumeros;
 
    } while (i < numbers.length);
    
    int average = sum / numbers.length;
    System.out.println("Media: " + average);
    
    Arrays.sort(numbers);
    
    int currentCount = 1;
    int currentNumber = numbers[0];
    for (i = 1; i < numbers.length; i++) {
      if (numbers[i] == currentNumber) {
        currentCount++;
      } else {
        if (currentCount > maxCount) {
          mode = currentNumber;
          maxCount = currentCount;
        }
        currentNumber = numbers[i];
        currentCount = 1;
      }
    }
    
    System.out.println("Moda: " + mode);
  }
    }


