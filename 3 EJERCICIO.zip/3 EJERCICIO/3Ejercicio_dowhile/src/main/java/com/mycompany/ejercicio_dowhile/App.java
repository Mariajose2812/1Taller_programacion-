/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.ejercicio_dowhile;

/**
 *
 * @author Maria jose
 */
//dowhile
import java.util.Random;
import java.util.Scanner;
public class App {

    public static void main(String[] args) {
        Random rand = new Random();
        Scanner teclado = new Scanner(System.in);
        
        int numeroproductos = rand.nextInt(31) + 1;
        
        System.out.println("Numero de productos:" + numeroproductos);
        String[] articulos = new String[numeroproductos];
        int[] cantidades = new int[numeroproductos];  
        double[] precios = new double[numeroproductos];
        
        int m = 0;
        do {
            System.out.println("Escriba el nombre del producto " + (m + 1) + ":");
            articulos[m] = teclado.nextLine();
            System.out.println("Escrba la cantidad de productos que desea " + (m + 1) + ":");
            cantidades[m] = teclado.nextInt();
            System.out.println("Precio del producto " + (m + 1) + ":");
            precios[m] = teclado.nextDouble();
            teclado.nextLine();
            m++;

        } while (m < numeroproductos);
        System.out.println("Productos generados:");
        for (m = 0; m < numeroproductos; m++) {
            System.out.println(articulos[m] + " = " + cantidades[m] + " = $ " + precios[m]);
        }
    
    
    }
}
