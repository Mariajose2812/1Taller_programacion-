/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.ejercicio_while;

/**
 *
 * @author Maria jose
 */
//while
import java.util.Random;
import java.util.Scanner;

public class App {

    public static void main(String[] args) {
        Random rand = new Random();
        Scanner teclado = new Scanner(System.in);
  
        int numeroproductos = rand.nextInt(31) + 1;
        
        System.out.println("Numero de productos: " + numeroproductos);
        String[] productos = new String[numeroproductos];
        int[] cantidades = new int[numeroproductos];
        double[] precios = new double[numeroproductos];

        int j = 0;
        while (j < numeroproductos) {
            System.out.println("Escriba el nombre del producto " + (j + 1) + ":");
            productos[j] = teclado.nextLine();
            System.out.println("Escrba la cantidad de productos que desea" + (j + 1) + ":");
            cantidades[j] = teclado.nextInt();
            System.out.println("Precio del producto " + (j + 1) + ":");
            precios[j] = teclado.nextDouble();
            teclado.nextLine();
            j++;
        }
        System.out.println("Productos generados:");
        for (j = 0; j < numeroproductos; j++) {
            System.out.println(productos[j] + " = " + cantidades[j] + " = $ " + precios[j]);
        }
        
    }
}
