/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.tabla_de_multiplicar_foreach;

/**
 *
 * @author Maria jose
 */

public class Tabla_de_multiplicar_foreach {

    public static void main(String[] args) {
        
        int NumeroA = (int)Math.floor(Math.random()*10+1); 
        int NumeroB = (int)Math.floor(Math.random()*10+1); 
        int [] multi = new int [NumeroB + 1];
        
       System.out.println("PRIMER DIGITO:MULTIPLICANDO "+ NumeroA);
       System.out.println("SEGUNDO DIGITO:MULTIPLICADOR " + NumeroB);
       
    
    for (int i=0; i<=NumeroB; i++){
        multi[i]=i;
    }
    for(int array:multi){
        System.out.println(NumeroA + " * " +array+ " = " + NumeroA*array);
    }
     }
         
         
    }
        
         
        
        
        
        
    

