/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.tabla_de_multiplicar_whlie;

/**
 *
 * @author Maria jose
 */
public class Tabla_de_multiplicar_whlie {

    public static void main(String[] args) {
       
         
        int NumeroA = (int)Math.floor(Math.random()*10+1); 
        int NumeroB = (int)Math.floor(Math.random()*10+1); 
        int [] multi = new int [NumeroB + 1];
        int x=0;
        
       System.out.println("PRIMER DIGITO:MULTIPLICANDO "+ NumeroA);
       System.out.println("SEGUNDO DIGITO:MULTIPLICADOR " + NumeroB);
       
         while(x<NumeroB){
         x++;
         System.out.println(NumeroA + " * " +x+ " = " + NumeroA*x); 
     }
    
        
        
        
    }
}
  