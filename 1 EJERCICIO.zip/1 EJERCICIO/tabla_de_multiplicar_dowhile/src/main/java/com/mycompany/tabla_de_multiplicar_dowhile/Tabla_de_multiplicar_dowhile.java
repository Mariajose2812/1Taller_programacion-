/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.tabla_de_multiplicar_dowhile;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;

public class Tabla_de_multiplicar_dowhile {

    public static void main(String[] args) {
       int NumeroA = (int)Math.floor(Math.random()*10+1);
        int NumeroB = (int)Math.floor(Math.random()*10+1);
        int i= 0;  
        
    Scanner teclado = new Scanner(System.in);    
    
    System.out.println("PRIMER DIGITO: MULTIPLICANDO :" + NumeroA);
         
    System.out.println("SEGUNDO DIGITO: MULTIPLICADOR : " + NumeroB);
    
    do{
        i++;
        System.out.println(NumeroA + "*" + i + "=" + NumeroA*i); 
        
    }while(i<NumeroB);
    
       
    
    
    }
}
