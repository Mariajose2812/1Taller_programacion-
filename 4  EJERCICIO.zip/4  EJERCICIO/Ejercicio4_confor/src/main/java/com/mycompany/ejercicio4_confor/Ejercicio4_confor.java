/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.ejercicio4_confor;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Ejercicio4_confor {

    public static void main(String[] args) {
       
    Scanner sc = new Scanner(System.in);
    System.out.print("Ingrese la palabra que desea: ");
    String word = sc.nextLine();

    System.out.print("Esta es la palabra invertida: ");
    for (int m = word.length() - 1; m >= 0; m--) {
      System.out.print(word.charAt(m ));
    }
    System.out.println();
  }
} 
    

