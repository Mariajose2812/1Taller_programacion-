/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.ejercicio4_con_while;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Ejercicio4_con_while {

    public static void main(String[] args) {
        
        
        Scanner sc = new Scanner(System.in);
    System.out.print("Ingrese la palabra que desea:");
    String word = sc.nextLine();

    int i = word.length() - 1;
    System.out.print("Esta es la palabra invertida: ");
    while (i >= 0) {
      System.out.print(word.charAt(i));
      i--;
    }
    System.out.println();
  }
}
    

