/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.ejercico4con_foreach;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Ejercico4con_foreach {

    public static void main(String[] args) {
       
        Scanner sc = new Scanner(System.in);
    System.out.print("Ingrese la palabra que desea: ");
    String word = sc.nextLine();

    System.out.print("Esta es la palabra invertida: ");
    for (int p = word.length() - 1; p >= 0; p--) {
      System.out.print(word.charAt(p));
    }
    System.out.println();
  }
}




    

